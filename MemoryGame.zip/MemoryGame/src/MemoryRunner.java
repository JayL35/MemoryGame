public class MemoryRunner {
    public static void main(String[] args) {
        Memory newGame = new Memory();
        newGame.start();
    }
}
